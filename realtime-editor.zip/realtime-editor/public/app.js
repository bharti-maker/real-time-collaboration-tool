// ============================================
// app.js - This runs in the USER'S browser
// It connects to our server using socket.io
// ============================================

// Connect to the server using socket.io
// This automatically finds our server at the same address
var socket = io();

// Get references to the HTML elements we'll use
var editor = document.getElementById('editor');
var statusBox = document.getElementById('status');

// ============================================
// CONNECTION EVENTS
// ============================================

// Fires when we successfully connect to the server
socket.on('connect', function() {
    statusBox.textContent = '🟢 Connected — you are live!';
    statusBox.className = 'status connected';
});

// Fires if we lose connection to the server
socket.on('disconnect', function() {
    statusBox.textContent = '🔴 Disconnected — trying to reconnect...';
    statusBox.className = 'status disconnected';
});

// ============================================
// RECEIVING TEXT FROM SERVER
// ============================================

// When we first join, server sends us the current text
// This event is emitted by server.js when we connect
socket.on('load-text', function(text) {
    editor.value = text;
});

// When ANOTHER user types, server sends us the new text
// We update our textarea to match
socket.on('text-update', function(text) {
    // Save where the cursor is before changing text
    // (so our cursor doesn't jump to the end)
    var cursorPos = editor.selectionStart;

    // Update the text
    editor.value = text;

    // Put cursor back where it was
    editor.setSelectionRange(cursorPos, cursorPos);
});

// ============================================
// SENDING TEXT TO SERVER
// ============================================

// Every time the user types something in the textarea,
// we send the new text to the server
editor.addEventListener('input', function() {
    // Get the current text from the textarea
    var currentText = editor.value;

    // Send it to the server — server will forward it to others
    socket.emit('text-change', currentText);
});
