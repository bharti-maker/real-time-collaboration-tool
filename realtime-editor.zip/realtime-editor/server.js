// ============================================
// server.js - This is the main backend file
// It runs on Node.js and handles all connections
// ============================================

// We need two things:
// 1. express - to create a basic web server
// 2. socket.io - to handle real-time connections between users
const express = require('express');
const http = require('http');
const socketIO = require('socket.io');

// Create the express app
const app = express();

// Wrap express inside an http server
// (socket.io needs this to work)
const server = http.createServer(app);

// Attach socket.io to our server
const io = socketIO(server);

// Tell express to serve all files from the "public" folder
// So when someone visits our website, they get index.html
app.use(express.static('public'));

// This stores the current text in the editor
// All users will get this text when they first join
let currentText = "";

// ============================================
// SOCKET.IO - The real-time magic happens here
// ============================================

// This runs every time a NEW user connects to our site
io.on('connection', function(socket) {

    console.log('A user connected! ID: ' + socket.id);

    // When a new user joins, send them the current text
    // So they see what others have already typed
    socket.emit('load-text', currentText);

    // This listens for typing from any user
    // When someone types, the client sends 'text-change' event
    socket.on('text-change', function(newText) {
        // Save the new text so future users can load it
        currentText = newText;

        // Send the updated text to ALL OTHER users (not the one who typed)
        // socket.broadcast = send to everyone EXCEPT this socket
        socket.broadcast.emit('text-update', newText);
    });

    // This runs when a user closes the tab or disconnects
    socket.on('disconnect', function() {
        console.log('A user disconnected! ID: ' + socket.id);
    });

});

// Start the server on port 3000
// Visit http://localhost:3000 to use the app
server.listen(3000, function() {
    console.log('Server is running at http://localhost:3000');
});
